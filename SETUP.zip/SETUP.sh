echo 
echo


echo "Wait For All Package Install"

echo
echo
echo


apt update

apt upgrade

termux-setup-storage

pkg install python -y

pkg install python2 -y

pkg install python-static -y

pkg install python-tkinter -y

pkg install vim-python -y

pkg install python2-static -y

pkg install weechat-python-plugin -y

pkg install git -y

pkg install figlet -y

pkg install cmatrix -y

pkg install toilet -y

pkg install nano -y

pkg install php -y

pkg install fish -y

pip install astroid 

pip install autopep8

pip install certifi

pip install chardet

pip install colorama 

pip install future

pip install idna 

pip install isort 

pip install lazy-object-proxy

pip install lolcat 

pip install mccabe  

pip install Pillow 

pip install pilo 

pip install pip

pip install pycodestyle 

pip install pyfiglet

pip install pylint

pip install requests 

pip install setuptools

pip install six

pip install termcolor

pip install toml

pip install urllib3

pip install wheel

pip install wrapt

pip install youtube-dl

pip install mechanize 

apt install ruby -y

apt install openssh -y

apt install wget -y

apt install curl -y

apt install proot -y


figlet -f slant 'MR-ZIHAD' |lolcat
echo
echo
echo 
figlet -f slant 'WELLCOME' |lolcat
echo
echo
echo

echo "Now Your Termux Is Ready To Run," |lolcat